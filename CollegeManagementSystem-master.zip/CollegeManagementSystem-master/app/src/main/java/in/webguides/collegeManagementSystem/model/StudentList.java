package in.webguides.collegeManagementSystem.model;

/**
 * Created by Jerry on 15-06-2017.
 */

public class StudentList {
}
